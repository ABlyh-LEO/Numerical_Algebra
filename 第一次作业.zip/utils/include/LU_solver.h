//
// Created by Yanhong Liu on 2025/9/30.
//
#pragma once

#include "matrix_utils.h"

template<typename T, int _dim>
class LU_Solver {
private:
    Matrix<T, _dim, _dim> Res;
public:
    LU_Solver() = default;

    ~LU_Solver() = default;

    void compute(Matrix<T, _dim, _dim> &A) {
        Res = A;
        for (int k = 0; k < _dim; ++k) {
            if (Res[k][k] == 0) {
                std::cerr << "Error(LU_Solver): Trying to use 0 as a divisor!" << std::endl;
                return;
            }
            for (int i = k + 1; i < _dim; ++i) {
                Res[i][k] /= Res[k][k];
                for (int j = k + 1; j < _dim; ++j) {
                    Res[i][j] -= Res[i][k] * Res[k][j];
                }
            }
        }
    }

    Matrix<T, _dim, 1> solve(const Matrix<T, _dim, 1> &b) {
        Matrix<T, _dim, 1> y, x;
        for (int i = 0; i < _dim; ++i) {
            y[i][0] = b[i][0];
            for (int j = 0; j < i; ++j) {
                y[i][0] -= Res[i][j] * y[j][0];
            }
        }
        for (int i = _dim - 1; i >= 0; --i) {
            x[i][0] = y[i][0];
            for (int j = i + 1; j < _dim; ++j) {
                x[i][0] -= Res[i][j] * x[j][0];
            }
            x[i][0] /= Res[i][i];
        }
        return x;
    }
};

template<typename T, int _dim>
class PLU_Solver {
private:
    Matrix<T, _dim, _dim> Res;
    int P[_dim]{};
public:
    PLU_Solver() = default;

    ~PLU_Solver() = default;

    void compute(Matrix<T, _dim, _dim> &A) {
        Res = A;
        for (int i = 0; i < _dim; ++i) P[i] = i;
        for (int k = 0; k < _dim; ++k) {
            int maxIndex = k;
            for (int i = k + 1; i < _dim; ++i) {
                if (std::abs(Res[i][k]) > std::abs(Res[maxIndex][k])) {
                    maxIndex = i;
                }
            }
            if (Res[maxIndex][k] == 0) {
                std::cerr << "Error(PLU_Solver): Trying to use 0 as a divisor!" << std::endl;
                return;
            }
            if (maxIndex != k) {
                std::swap(P[k], P[maxIndex]);
                for (int j = 0; j < _dim; ++j) {
                    std::swap(Res[k][j], Res[maxIndex][j]);
                }
            }
            for (int i = k + 1; i < _dim; ++i) {
                Res[i][k] /= Res[k][k];
                for (int j = k + 1; j < _dim; ++j) {
                    Res[i][j] -= Res[i][k] * Res[k][j];
                }
            }
        }
    }

    Matrix<T, _dim, 1> solve(const Matrix<T, _dim, 1> &b) {
        Matrix<T, _dim, 1> y, x;
        for (int i = 0; i < _dim; ++i) {
            y[i][0] = b[P[i]][0];
            for (int j = 0; j < i; ++j) {
                y[i][0] -= Res[i][j] * y[j][0];
            }
        }
        for (int i = _dim - 1; i >= 0; --i) {
            x[i][0] = y[i][0];
            for (int j = i + 1; j < _dim; ++j) {
                x[i][0] -= Res[i][j] * x[j][0];
            }
            x[i][0] /= Res[i][i];
        }
        return x;
    }
};